package runner1;


import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.CucumberOptions.SnippetType;
import steps1.BaseClassDeleteLead;

@CucumberOptions(features = "src/test/java/features1/DeleteLead.feature", glue="steps1",
                 monochrome = true, dryRun = false, snippets = SnippetType.CAMELCASE, publish = true)

public class DeleteLeadRunner extends BaseClassDeleteLead {

}
