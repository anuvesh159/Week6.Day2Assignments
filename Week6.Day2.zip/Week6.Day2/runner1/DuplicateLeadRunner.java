package runner1;

import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.CucumberOptions.SnippetType;
import steps1.BaseClassDuplicateLead;

@CucumberOptions(features = "src/test/java/features1/DuplicateLead.feature", glue="steps1",
monochrome = true, dryRun = false, snippets = SnippetType.CAMELCASE, publish = true)



public class DuplicateLeadRunner extends BaseClassDuplicateLead {

}
