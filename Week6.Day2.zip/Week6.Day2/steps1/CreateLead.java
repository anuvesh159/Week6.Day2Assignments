package steps1;

import org.openqa.selenium.By;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CreateLead extends BaseClassCreateLead{

	@When ("Click the CreateLead Button")
	public void clickCreateLeadButton() {
		
		driver.findElement(By.linkText("Create Lead")).click();
	}
	
	@Then ("CreateLead Page opens")
	public void leadPageDisplays() {
		
		boolean leadsPage = driver.findElement(By.id("sectionHeaderTitle_leads")).isDisplayed();
		if(leadsPage==true) {
			System.out.println("Open Create Lead Page");
		}
		else {
			System.out.println("Not open Create Lead Page");
		}		
	}
	
	
	@Given ("Enter the  Company Name as {string}")
	public void companyName(String cName) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
	}
	
	@Given ("Enter the Father Name as {string}")
	public void fatherName(String fName) {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
	}
	
	@Given ("Enter the Last Name as {string}")
	public void lastName(String Lname) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(Lname);
	}
	@Given ("Enter the Email Address as {string}")
	public void enterEmailAddress(String email) {
		driver.findElement(By.id("createLeadForm_primaryEmail")).sendKeys(email);
	}
	
	@Given ("Enter the PhoneNumber as {string}")
	public void enterPhoneNumber(String Phonenumb) {
		driver.findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys(Phonenumb);
	}
	
	@When ("click the Submit button")
	public void submitButton() throws InterruptedException {
		driver.findElement(By.className("submitButton")).click();
		Thread.sleep(2000);
	}
	
	@Then ("View page is shown")
	public void viewLead() {
		boolean viewLeadPage = driver.findElement(By.xpath("//div[text()[normalize-space()='View Lead']")).isDisplayed();
		if(viewLeadPage==true) {
			System.out.println("Lead is created successfull");
		}else {
			
			System.out.println("Lead is not created");
		}
		
	}
	
	
	
	
}
